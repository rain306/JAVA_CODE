import java.util.Scanner;
import java.util.Arrays;
public class Level2
{
    public static void main(String[] args)
    {

        Scanner scanner=new Scanner(System.in);
        int[] arr={33,19,4,20,100};
        System.out.println("排序前的结果");
        for(int i =0;i<arr.length;i++)
        {
            System.out.print(arr[i]+",");
        }
        System.out.println();
        for (int i = 1; i < arr.length; i++)
        {
            boolean flag = true;
            for (int j = 0; j < arr.length-1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    int tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                    flag = false;
                }
                if (flag)
                {
                    break;
                }
            }

        }
        System.out.println("排序后的结果");
        for(int i =0;i<arr.length;i++)
        {
            System.out.print(arr[i]+",");
        }
        System.out.println();
        int[] arr2 =new int[arr.length+1];
        for(int i =0;i<arr.length;i++)
        {
            arr2[i]=arr[i];
        }
        System.out.println("输入一个新的食物的价格");
        arr2[arr2.length-1]=scanner.nextInt();
        for(int i = 0;i<arr2.length-1;i++)
        {
            int flag=i;
            for(int j=i+1;j<arr2.length;j++)
            {
                if(arr2[j]<arr2[flag])
                {
                    flag = j;
                }
            }
            if(flag!=i)
            {
                int tmp=arr2[i];
                arr2[i]=arr2[flag];
                arr2[flag]=tmp;
            }
        }
        System.out.println("插入新食物后的价格数组为");
        for(int i =0;i<arr2.length;i++)
        {
            System.out.print(arr2[i]+",");
        }
    }
}