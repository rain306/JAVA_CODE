import java.util.Scanner;
import java.util.Random;



public class Level3
{

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int input;
        boolean inputNew;
        do
        {
            System.out.println("*********************");
            System.out.println("***  1.开始游戏    ****");
            System.out.println("***  0.退出游戏    ****");
            input = scanner.nextInt();
            inputNew = input != 0;
            switch(input)
            {
                case 1:
                    game();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("选择错误,请重新选择!");
            }
        }while(inputNew);


       // System.out.println(getNum);



    }

    static void game()
    {
        Scanner scanner = new Scanner(System.in);
        String[][] pool = {{"超级稀有"}, {"稀有", "稀有", "稀有", "稀有"}, {"普通", "普通", "普通", "普通", "普通", "普通", "普通"
                , "普通"}};
        Random roll = new Random();
        int input;
        boolean inputNew;
        int mode;
        boolean modeNew=true;
        do
        {
            System.out.println("***  请选择抽卡次数 ***");
            System.out.println("***  1.单抽出奇迹  ***");
            System.out.println("***  2.十连散欧气  ***");
            mode = scanner.nextInt();//选择抽卡模式
            switch (mode)
            {
                case 1:
                    int getNum = roll.nextInt(100);
                    if (getNum < 2)
                        System.out.println(pool[0][0]);
                    else if (2 < getNum && getNum < 20)
                        System.out.println(pool[1][0]);
                    else
                        System.out.println(pool[2][0]);
                    break;
                case 2:
                    for (int i = 0; i < 10; i++)
                    {
                        getNum = roll.nextInt(100);
                        if (getNum < 2)
                            System.out.println(pool[0][0]);
                        else if (2 < getNum && getNum < 20)
                            System.out.println(pool[1][0]);
                        else
                            System.out.println(pool[2][0]);
                    }
                    break;
                default:
                    System.out.println("选择错误,请重新选择!");
                    break;
            }
            if(mode==1||mode==2)
                modeNew=false;
        }while(modeNew);
    }
}